const carousel = document.querySelector('.carousel');
let scrollAmount = 0;

function autoScroll() {
    const maxScroll = carousel.scrollWidth - carousel.clientWidth;
    if (scrollAmount >= maxScroll) {
        scrollAmount = 0; // Reset scroll to the start
    } else {
        scrollAmount += 150; // Adjust scroll increment
    }
    carousel.scrollTo({
        left: scrollAmount,
        behavior: "smooth"
    });
}

// Auto-scroll every 5 seconds
setInterval(autoScroll, 5000);
