// scripts.js
document.querySelectorAll('.product-carousel').forEach((carousel) => {
    let isDown = false;
    let startX;
    let scrollLeft;
  
    // Mouse and touch scroll functionality
    carousel.addEventListener('mousedown', (e) => {
      isDown = true;
      carousel.classList.add('active');
      startX = e.pageX - carousel.offsetLeft;
      scrollLeft = carousel.scrollLeft;
    });
  
    carousel.addEventListener('mouseleave', () => {
      isDown = false;
      carousel.classList.remove('active');
    });
  
    carousel.addEventListener('mouseup', () => {
      isDown = false;
      carousel.classList.remove('active');
    });
  
    carousel.addEventListener('mousemove', (e) => {
      if (!isDown) return;
      e.preventDefault();
      const x = e.pageX - carousel.offsetLeft;
      const walk = (x - startX) * 2; // Scroll fast
      carousel.scrollLeft = scrollLeft - walk;
    });
  
    // Touch support
    carousel.addEventListener('touchstart', (e) => {
      isDown = true;
      startX = e.touches[0].pageX - carousel.offsetLeft;
      scrollLeft = carousel.scrollLeft;
    });
  
    carousel.addEventListener('touchend', () => {
      isDown = false;
    });
  
    carousel.addEventListener('touchmove', (e) => {
      if (!isDown) return;
      const x = e.touches[0].pageX - carousel.offsetLeft;
      const walk = (x - startX) * 2;
      carousel.scrollLeft = scrollLeft - walk;
    });
  
    // Automatic scrolling
    let scrollPosition = 0;
    const scrollStep = carousel.offsetWidth; // Scroll by carousel width
    const maxScroll = carousel.scrollWidth - carousel.offsetWidth;
  
    setInterval(() => {
      scrollPosition += scrollStep;
      if (scrollPosition > maxScroll) {
        scrollPosition = 0; // Reset to start
      }
      carousel.scrollTo({
        left: scrollPosition,
        behavior: 'smooth',
      });
    }, 3000); // 3-second interval
  });
  